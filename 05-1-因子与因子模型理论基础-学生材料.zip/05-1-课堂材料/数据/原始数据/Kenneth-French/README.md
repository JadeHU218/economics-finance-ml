# Kenneth French 美国月度研究因子

本目录保存第五讲 `05-1 因子与因子模型理论基础` 使用的官方原始压缩包。下载日期为 **2026-10-20**；两个文件均说明使用 **202608 CRSP database** 生成。原始压缩包保持不变，课堂读取的是同目录脚本按共同月份生成的 `../../ff3_momentum_monthly.csv`。

## 原始文件与校验值

| 文件 | 官方下载页 | SHA256 |
| --- | --- | --- |
| `F-F_Research_Data_Factors_CSV.zip` | [Fama/French 3 Factors 的 CSV 入口](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html) | `593f4fbef03181bc0b22ff6292f217689dd1fb79355049ca905d95b262040a66` |
| `F-F_Momentum_Factor_CSV.zip` | [Momentum Factor (Mom) 的 CSV 入口](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html) | `c06d1c2e9a5e4f6985879722f23c6bb585f46b34eaf3fcb681d4de887e353f3e` |

直接下载地址分别为：

- `https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Research_Data_Factors_CSV.zip`
- `https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/ftp/F-F_Momentum_Factor_CSV.zip`

官方构造说明：[FF3](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/f-f_factors.html)；[月度 Mom](https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/Data_Library/det_mom_factor.html)。数据来自美国 NYSE、AMEX 与 NASDAQ 股票。`Mkt-RF` 为市场超额收益；SMB 与 HML 来自规模和账面市值比的六个市值加权组合；Mom 来自规模与过去第 12 至第 2 月收益的六个市值加权组合。

## 合并规则

运行：

```bash
python 数据/原始数据/Kenneth-French/build_ff3_momentum.py
```

脚本只读取压缩包中的六位 `YYYYMM` 月度记录，不读取后面的年度表；把官方缺失码 `-99.99`、`-999` 视为失败；按月份内连接两张表，不插值、不缩尾。共同样本为 **1927-01—2026-08，共1196个月**，月份连续且没有缺失值。

输出字段为 `month, mkt_excess_pct, smb_pct, hml_pct, mom_pct, rf_pct`。`_pct` 表示**当月百分数/百分点**，例如 `2.50` 表示当月 `2.50%`，不是小数 `0.025`。Notebook 只有在需要小数运算时才除以100。

## 使用边界

这是有来源的美国历史研究因子，不是A股因子，也不是课程合成数据。官方会随 CRSP 数据修订重建历史序列，因此两张表必须使用同一版本，不能把本目录的202608文件与其他发布日期的因子拼接。

SMB、HML、Mom 是多空研究组合的收益差，`Mkt-RF` 是市场超额收益。Notebook 中的累计和只用于观察长期正负贡献和阶段变化，不是基金净值，也没有计入实际借券、融资、交易成本和可成交约束。
