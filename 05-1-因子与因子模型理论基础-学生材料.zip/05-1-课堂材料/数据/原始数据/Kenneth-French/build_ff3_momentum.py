"""把同一版 Kenneth French FF3 与 Mom 月度文件合并为课堂输入。"""

from __future__ import annotations

import csv
import hashlib
import io
from pathlib import Path
import zipfile


RAW_DIR = Path(__file__).resolve().parent
DATA_DIR = RAW_DIR.parents[1]
FF3_ZIP = RAW_DIR / "F-F_Research_Data_Factors_CSV.zip"
MOM_ZIP = RAW_DIR / "F-F_Momentum_Factor_CSV.zip"
OUTPUT = DATA_DIR / "ff3_momentum_monthly.csv"
MISSING_CODES = {-99.99, -999.0}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_first_member(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as archive:
        members = [name for name in archive.namelist() if not name.endswith("/")]
        if len(members) != 1:
            raise ValueError(f"{path.name} 应只有一个数据文件，实际为 {members}")
        text = archive.read(members[0]).decode("utf-8-sig")
    return text.splitlines()


def parse_csv_line(line: str) -> list[str]:
    return [item.strip() for item in next(csv.reader(io.StringIO(line)), [])]


def read_monthly_table(path: Path, columns: list[str]) -> dict[str, list[float]]:
    expected_header = [""] + columns
    lines = read_first_member(path)
    header_index = None
    for index, line in enumerate(lines):
        row = parse_csv_line(line)
        if row == expected_header:
            header_index = index
            break
    if header_index is None:
        raise ValueError(f"{path.name} 未找到月度表头 {expected_header}")

    result: dict[str, list[float]] = {}
    for line in lines[header_index + 1 :]:
        row = parse_csv_line(line)
        if not row or len(row[0]) != 6 or not row[0].isdigit():
            if result:
                break
            continue
        if len(row) != len(expected_header):
            raise ValueError(f"{path.name} 月度行字段数异常：{row}")
        values = [float(item) for item in row[1:]]
        if any(value in MISSING_CODES for value in values):
            raise ValueError(f"{path.name} {row[0]} 含官方缺失码：{values}")
        if row[0] in result:
            raise ValueError(f"{path.name} 月份重复：{row[0]}")
        result[row[0]] = values
    return result


def next_month(yyyymm: str) -> str:
    year = int(yyyymm[:4])
    month = int(yyyymm[4:])
    if month == 12:
        return f"{year + 1:04d}01"
    return f"{year:04d}{month + 1:02d}"


def check_contiguous(months: list[str]) -> None:
    for left, right in zip(months, months[1:]):
        if next_month(left) != right:
            raise ValueError(f"共同样本月份不连续：{left} 后为 {right}")


def main() -> None:
    ff3 = read_monthly_table(FF3_ZIP, ["Mkt-RF", "SMB", "HML", "RF"])
    mom = read_monthly_table(MOM_ZIP, ["Mom"])
    common = sorted(set(ff3).intersection(mom))
    if not common:
        raise ValueError("FF3 与 Mom 没有共同月份")
    check_contiguous(common)

    with OUTPUT.open("w", encoding="utf-8", newline="") as target:
        writer = csv.writer(target)
        writer.writerow(
            [
                "month",
                "mkt_excess_pct",
                "smb_pct",
                "hml_pct",
                "mom_pct",
                "rf_pct",
            ]
        )
        for month in common:
            mkt, smb, hml, rf = ff3[month]
            mom_value = mom[month][0]
            writer.writerow(
                [
                    f"{month[:4]}-{month[4:]}",
                    f"{mkt:.2f}",
                    f"{smb:.2f}",
                    f"{hml:.2f}",
                    f"{mom_value:.2f}",
                    f"{rf:.2f}",
                ]
            )

    print(f"FF3 月数：{len(ff3)}，Mom 月数：{len(mom)}")
    print(f"共同月份：{common[0]}—{common[-1]}，共 {len(common)} 个月")
    print(f"输出：{OUTPUT}")
    print(f"FF3 zip SHA256：{sha256(FF3_ZIP)}")
    print(f"Mom zip SHA256：{sha256(MOM_ZIP)}")
    print(f"合并 CSV SHA256：{sha256(OUTPUT)}")


if __name__ == "__main__":
    main()
